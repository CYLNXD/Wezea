// ─── CyberHealth Scanner — API Client ─────────────────────────────────────────
import axios, { AxiosError } from 'axios';
import type { ScanResult } from '../types/scanner';

const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8000';

export const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 60_000, // 60s — les scans de ports peuvent être longs
  headers: { 'Content-Type': 'application/json' },
});

// ── Endpoints ─────────────────────────────────────────────────────────────────

export async function scanDomain(domain: string): Promise<ScanResult> {
  const { data } = await apiClient.post<ScanResult>('/scan', { domain });
  return data;
}

export async function requestFullReport(payload: {
  domain:      string;
  email:       string;
  first_name?: string;
  last_name?:  string;
  company?:    string;
  scan_data?:  Record<string, unknown> | null;
}): Promise<{ lead_id: string; scan_id?: string; message: string }> {
  const { data } = await apiClient.post('/report/request', payload);
  return data;
}

/**
 * Génère le rapport PDF et retourne un Blob téléchargeable.
 * Envoie le JSON complet du scan à POST /generate-pdf.
 */
export async function generatePDF(scanResult: ScanResult): Promise<Blob> {
  const response = await apiClient.post('/generate-pdf', scanResult, {
    responseType: 'blob',
    timeout:      90_000,   // WeasyPrint peut nécessiter plus de temps
  });
  return new Blob([response.data], { type: 'application/pdf' });
}

/**
 * Déclenche le téléchargement navigateur d'un Blob PDF.
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url  = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href     = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

// ── Error helper ──────────────────────────────────────────────────────────────

export function extractApiError(err: unknown): string {
  if (err instanceof AxiosError) {
    const detail = err.response?.data?.detail;
    if (typeof detail === 'string') return detail;
    if (detail?.message) return detail.message;
    if (err.response?.status === 422) return 'Domaine invalide. Vérifiez le format (ex: exemple.fr).';
    if (err.response?.status === 429) return 'Trop de requêtes. Veuillez patienter une minute.';
    if (err.code === 'ECONNABORTED') return 'Le scan a pris trop de temps. Réessayez.';
  }
  return 'Erreur inattendue. Veuillez réessayer.';
}
