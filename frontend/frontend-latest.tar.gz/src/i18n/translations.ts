// ─── Traductions FR / EN ──────────────────────────────────────────────────────

export type Lang = 'fr' | 'en';

export const translations = {
  fr: {
    // ── Dashboard — Hero ──────────────────────────────────────────────────────
    hero_badge:        'Scan passif — aucune perturbation de votre infrastructure',
    hero_title_1:      'Votre entreprise est-elle',
    hero_title_2:      'une cible facile\u00a0?',
    hero_subtitle:     "Analysez l'empreinte publique de votre domaine en 30\u00a0secondes. En-têtes HTTP, SPF/DKIM/DMARC, SSL, ports, réputation IP\u00a0— obtenez votre SecurityScore.",
    hero_try:          'Essayez\u00a0:',
    placeholder:       'votreentreprise.fr',

    // ── Badges vérifications ──────────────────────────────────────────────────
    badge_headers:     'En-têtes HTTP',
    badge_spf:         'SPF\u00a0/\u00a0DKIM\u00a0/\u00a0DMARC',
    badge_ssl:         'SSL\u00a0/\u00a0TLS',
    badge_ports:       'Ports réseau',
    badge_tech:        'Technologies',
    badge_dnsbl:       'Listes noires',

    // ── Boutons / actions ─────────────────────────────────────────────────────
    btn_scan:          'Analyser',
    btn_new_scan:      'Nouveau scan',
    btn_retry:         'Réessayer',
    btn_report:        'Recevoir le rapport expert complet',
    btn_close:         'Fermer',
    btn_redownload:    'Re-télécharger le rapport PDF',

    // ── Résultats scan ────────────────────────────────────────────────────────
    scan_error:        'Scan impossible',
    scan_duration:     'Scanné en {ms}ms\u00a0·\u00a0{date}',
    vulns_found:       'Vulnérabilités détectées',
    vulns_none:        'Excellent\u00a0! Aucune vulnérabilité détectée.',
    vulns_none_sub:    "Votre infrastructure publique présente une bonne hygiène de sécurité. Un audit complet peut identifier des vecteurs d'attaque non visibles passivement.",
    findings_info:     "observation(s) informative(s)",
    ports_map:         'Carte des ports scannés',
    ports_open:        'ouvert(s)\u00a0/\u00a0{closed} fermé(s)',
    stat_vulns:        'Vulnérabilités',
    stat_ports:        'Ports critiques',
    stat_dns:          'Pénalités DNS',
    stat_ssl:          'Pénalités SSL',

    // ── Catégories findings ───────────────────────────────────────────────────
    cat_dns:           '📧 DNS & Mail',
    cat_ssl:           '🔒 SSL\u00a0/\u00a0HTTPS',
    cat_ports:         '🌐 Ports réseau',
    cat_headers:       '🛡️ En-têtes HTTP',
    cat_email_sec:     '📨 Sécurité Email',
    cat_tech:          '🔍 Technologie',
    cat_reputation:    '🌐 Réputation',

    // ── Groupes de findings (Dashboard) ──────────────────────────────────────
    group_dns:         'DNS & Mail',
    group_ssl:         'SSL\u00a0/\u00a0HTTPS',
    group_ports:       'Exposition Réseau',
    group_headers:     'En-têtes de Sécurité HTTP',
    group_email:       'Authentification Email',
    group_tech:        'Exposition Technologique',
    group_reputation:  'Réputation du Domaine',

    // ── Sévérités ─────────────────────────────────────────────────────────────
    sev_critical:      'CRITIQUE',
    sev_high:          'ÉLEVÉ',
    sev_medium:        'MODÉRÉ',
    sev_low:           'FAIBLE',
    sev_info:          'INFO',

    // ── FindingCard ───────────────────────────────────────────────────────────
    finding_meaning:   'Ce que ça signifie pour vous',
    finding_technical: 'Détail technique',
    finding_reco:      'Recommandation',

    // ── ScoreGauge ────────────────────────────────────────────────────────────
    risk_critical:     'Critique',
    risk_high:         'Élevé',
    risk_medium:       'Modéré',
    risk_low:          'Faible',
    risk_label:        'Niveau de risque\u00a0:',
    gauge_scale_bad:   '0–39 Critique',
    gauge_scale_mid:   '40–69 Risqué',
    gauge_scale_good:  '70–100 Bon',

    // ── ScanConsole ───────────────────────────────────────────────────────────
    console_title:     'cyberhealth-scanner — audit {domain}',
    console_scanning:  'Analyse en cours...',
    console_passive:   'Scan passif en cours — aucune modification effectuée sur votre infrastructure',

    // ── CTABanner ─────────────────────────────────────────────────────────────
    cta_title_critical: '🚨 Infrastructure en danger immédiat',
    cta_title_high:     '⚠️ Risques de sécurité détectés',
    cta_body_critical:  'Avec un score de {score}/100, {domain} est exposé à des attaques ransomware imminentes.',
    cta_body_high:      'Votre score de {score}/100 indique des vulnérabilités exploitables par des attaquants opportunistes.',
    cta_audit:          'Audit gratuit 30 min',
    cta_call:           'Appeler maintenant',

    // ── FinancialRiskCard ─────────────────────────────────────────────────────
    fin_title:          "Estimation de l'Impact Financier",
    fin_subtitle:       'En cas de cyberattaque réussie sur cette infrastructure',
    fin_model:          'Modèle de calcul (PME, basé données ANSSI 2024)',
    fin_formula:        'Perte = (C_interruption × Jours) + C_restauration + Amende_RGPD',
    fin_downtime:       'Interruption d\'activité ({label})',
    fin_downtime_calc:  '{daily}/j × {days} jours',
    fin_restore:        'Restauration des systèmes & données',
    fin_restore_sub:    'Forensique + sauvegardes + reconfig',
    fin_gdpr:           'Risque d\'amende RGPD (violation de données)',
    fin_gdpr_sub:       'Selon Art. 83 RGPD + notification CNIL',
    fin_total:          'Perte totale estimée',
    fin_range:          'fourchette\u00a0: {min}\u00a0—\u00a0{max}',
    fin_disclaimer:     "Estimation basée sur les données de sinistres ANSSI 2024 pour les PME de 10–250 salariés. Les chiffres réels varient selon le secteur, le chiffre d'affaires et la réactivité de l'équipe. Un audit expert permet d'affiner cette estimation et de prioriser les actions.",
    fin_risk:           'Risque {label}',
    downtime_critical:  '6–10 jours',
    downtime_high:      '3–5 jours',
    downtime_medium:    '1–3 jours',
    downtime_low:       '<1 jour',

    // ── EmailCaptureModal ─────────────────────────────────────────────────────
    modal_title:        'Rapport Expert Complet',
    modal_pdf_sub:      'Généré instantanément — PDF de 12 pages',
    modal_email_sub:    'Envoyé par email dans les 5 minutes',
    modal_critical_body: 'Score {score}/100 détecté. Votre rapport inclut un plan d\'action d\'urgence (J+7) et l\'estimation des pertes financières en cas d\'attaque.',
    modal_critical_cta: '+ 30 min de consultation offerte.',
    modal_normal_body_1:     'Rapport de',
    modal_normal_body_pages: '12 pages',
    modal_normal_body_2:     'incluant\u00a0: plan de remédiation, analyse RGPD/NIS2, et',
    modal_normal_body:  'Rapport de <strong>12 pages</strong> incluant\u00a0: plan de remédiation, analyse RGPD/NIS2, et',
    modal_consult:      '30 min de consultation offerte',
    modal_score:        'Score analysé\u00a0:',
    modal_firstname:    'Prénom *',
    modal_lastname:     'Nom *',
    modal_company:      'Entreprise (optionnel)',
    modal_email:        'votre@email.pro *',
    modal_btn_loading:  'Enregistrement…',
    modal_btn_pdf:      'Génération du PDF…',
    modal_btn_download: 'Télécharger mon rapport PDF',
    modal_btn_email:    'Recevoir mon rapport par email',
    modal_gen_title:    'Génération du rapport PDF en cours…',
    modal_gen_sub:      'Compilation des 12 pages, mise en page, export… (~15s)',
    modal_connect:      'Connexion au serveur…',
    modal_legal:        "En soumettant ce formulaire, vous acceptez d'être contacté par notre équipe.\u00a0Désabonnement en 1 clic\u00a0· Données protégées conformément au RGPD.",
    modal_success_pdf:  'Rapport téléchargé\u00a0! 📄',
    modal_success_req:  'Demande enregistrée\u00a0! 🚀',
    modal_success_pdf_body: 'Votre rapport PDF a été généré et téléchargé automatiquement. Vérifiez votre dossier Téléchargements.',
    modal_success_email_body: 'Votre rapport expert sera envoyé à {email} dans quelques minutes.',
    modal_next_steps:   'Prochaines étapes',
    modal_step1:        'Vérifiez votre boîte mail (et les spams) pour la confirmation.',
    modal_step2:        'Un consultant vous contactera sous 24h pour analyser vos résultats.',
    modal_step3:        '30 min de consultation offertes incluses dans le rapport.',
    modal_redownload:   'Re-télécharger le rapport PDF',
  },

  en: {
    // ── Dashboard — Hero ──────────────────────────────────────────────────────
    hero_badge:        'Passive scan — no disruption to your infrastructure',
    hero_title_1:      'Is your business',
    hero_title_2:      'an easy target?',
    hero_subtitle:     'Analyze your domain\'s public footprint in 30\u00a0seconds. HTTP headers, SPF/DKIM/DMARC, SSL, ports, IP reputation\u00a0— get your SecurityScore.',
    hero_try:          'Try:',
    placeholder:       'yourbusiness.com',

    // ── Badges vérifications ──────────────────────────────────────────────────
    badge_headers:     'HTTP Headers',
    badge_spf:         'SPF\u00a0/\u00a0DKIM\u00a0/\u00a0DMARC',
    badge_ssl:         'SSL\u00a0/\u00a0TLS',
    badge_ports:       'Network Ports',
    badge_tech:        'Technologies',
    badge_dnsbl:       'Blacklists',

    // ── Boutons / actions ─────────────────────────────────────────────────────
    btn_scan:          'Analyze',
    btn_new_scan:      'New scan',
    btn_retry:         'Retry',
    btn_report:        'Get the full expert report',
    btn_close:         'Close',
    btn_redownload:    'Re-download PDF report',

    // ── Résultats scan ────────────────────────────────────────────────────────
    scan_error:        'Scan failed',
    scan_duration:     'Scanned in {ms}ms\u00a0·\u00a0{date}',
    vulns_found:       'Vulnerabilities detected',
    vulns_none:        'Excellent! No vulnerabilities detected.',
    vulns_none_sub:    'Your public infrastructure shows good security hygiene. A full audit may uncover attack vectors not visible passively.',
    findings_info:     'informational finding(s)',
    ports_map:         'Scanned ports map',
    ports_open:        'open\u00a0/\u00a0{closed} closed',
    stat_vulns:        'Vulnerabilities',
    stat_ports:        'Critical ports',
    stat_dns:          'DNS penalties',
    stat_ssl:          'SSL penalties',

    // ── Catégories findings ───────────────────────────────────────────────────
    cat_dns:           '📧 DNS & Mail',
    cat_ssl:           '🔒 SSL\u00a0/\u00a0HTTPS',
    cat_ports:         '🌐 Network Ports',
    cat_headers:       '🛡️ HTTP Headers',
    cat_email_sec:     '📨 Email Security',
    cat_tech:          '🔍 Technology',
    cat_reputation:    '🌐 Reputation',

    // ── Groupes de findings (Dashboard) ──────────────────────────────────────
    group_dns:         'DNS & Mail',
    group_ssl:         'SSL\u00a0/\u00a0HTTPS',
    group_ports:       'Network Exposure',
    group_headers:     'HTTP Security Headers',
    group_email:       'Email Authentication',
    group_tech:        'Technology Exposure',
    group_reputation:  'Domain Reputation',

    // ── Sévérités ─────────────────────────────────────────────────────────────
    sev_critical:      'CRITICAL',
    sev_high:          'HIGH',
    sev_medium:        'MEDIUM',
    sev_low:           'LOW',
    sev_info:          'INFO',

    // ── FindingCard ───────────────────────────────────────────────────────────
    finding_meaning:   'What this means for you',
    finding_technical: 'Technical detail',
    finding_reco:      'Recommendation',

    // ── ScoreGauge ────────────────────────────────────────────────────────────
    risk_critical:     'Critical',
    risk_high:         'High',
    risk_medium:       'Moderate',
    risk_low:          'Low',
    risk_label:        'Risk level:',
    gauge_scale_bad:   '0–39 Critical',
    gauge_scale_mid:   '40–69 Risky',
    gauge_scale_good:  '70–100 Good',

    // ── ScanConsole ───────────────────────────────────────────────────────────
    console_title:     'cyberhealth-scanner — audit {domain}',
    console_scanning:  'Scanning in progress...',
    console_passive:   'Passive scan in progress — no changes made to your infrastructure',

    // ── CTABanner ─────────────────────────────────────────────────────────────
    cta_title_critical: '🚨 Infrastructure at immediate risk',
    cta_title_high:     '⚠️ Security risks detected',
    cta_body_critical:  'With a score of {score}/100, {domain} is exposed to imminent ransomware attacks.',
    cta_body_high:      'Your score of {score}/100 indicates vulnerabilities exploitable by opportunistic attackers.',
    cta_audit:          'Free 30-min audit',
    cta_call:           'Call now',

    // ── FinancialRiskCard ─────────────────────────────────────────────────────
    fin_title:          'Estimated Financial Impact',
    fin_subtitle:       'In the event of a successful cyberattack on this infrastructure',
    fin_model:          'Calculation model (SMB, based on ANSSI 2024 data)',
    fin_formula:        'Loss = (C_downtime × Days) + C_restoration + GDPR_fine',
    fin_downtime:       'Business interruption ({label})',
    fin_downtime_calc:  '{daily}/day × {days} days',
    fin_restore:        'System & data restoration',
    fin_restore_sub:    'Forensics + backups + reconfiguration',
    fin_gdpr:           'GDPR fine risk (data breach)',
    fin_gdpr_sub:       'Under Art. 83 GDPR + data authority notification',
    fin_total:          'Estimated total loss',
    fin_range:          'range:\u00a0{min}\u00a0—\u00a0{max}',
    fin_disclaimer:     'Estimate based on ANSSI 2024 incident data for SMBs with 10–250 employees. Actual figures vary by sector, revenue, and team response time. An expert audit allows you to refine this estimate and prioritize actions.',
    fin_risk:           '{label} risk',
    downtime_critical:  '6–10 days',
    downtime_high:      '3–5 days',
    downtime_medium:    '1–3 days',
    downtime_low:       '<1 day',

    // ── EmailCaptureModal ─────────────────────────────────────────────────────
    modal_title:        'Full Expert Report',
    modal_pdf_sub:      'Generated instantly — 12-page PDF',
    modal_email_sub:    'Sent by email within 5 minutes',
    modal_critical_body: 'Score {score}/100 detected. Your report includes an emergency action plan (D+7) and estimated financial losses in case of an attack.',
    modal_critical_cta: '+ 30 min free consultation included.',
    modal_normal_body_1:     'Report of',
    modal_normal_body_pages: '12 pages',
    modal_normal_body_2:     'including: remediation plan, GDPR/NIS2 analysis, and',
    modal_normal_body:  '<strong>12-page</strong> report including: remediation plan, GDPR/NIS2 analysis, and',
    modal_consult:      '30 min free consultation',
    modal_score:        'Analyzed score:',
    modal_firstname:    'First name *',
    modal_lastname:     'Last name *',
    modal_company:      'Company (optional)',
    modal_email:        'your@business.email *',
    modal_btn_loading:  'Saving…',
    modal_btn_pdf:      'Generating PDF…',
    modal_btn_download: 'Download my PDF report',
    modal_btn_email:    'Receive my report by email',
    modal_gen_title:    'Generating PDF report…',
    modal_gen_sub:      'Compiling 12 pages, layout, export… (~15s)',
    modal_connect:      'Connecting to server…',
    modal_legal:        'By submitting this form, you agree to be contacted by our team.\u00a0One-click unsubscribe\u00a0· Data protected under GDPR.',
    modal_success_pdf:  'Report downloaded! 📄',
    modal_success_req:  'Request registered! 🚀',
    modal_success_pdf_body: 'Your PDF report has been generated and downloaded automatically. Check your Downloads folder.',
    modal_success_email_body: 'Your expert report will be sent to {email} in a few minutes.',
    modal_next_steps:   'Next steps',
    modal_step1:        'Check your inbox (and spam folder) for the confirmation.',
    modal_step2:        'A consultant will contact you within 24h to review your results.',
    modal_step3:        '30 min free consultation included in the report.',
    modal_redownload:   'Re-download PDF report',
  },
} as const;

export type TranslationKey = keyof typeof translations.fr;
