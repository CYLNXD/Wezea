// ─── CyberHealth Scanner — useScanner Hook ────────────────────────────────────
//
// Gère :
//   1. L'appel API réel (POST /scan)
//   2. La simulation des logs de console (pour l'UX — indépendante de l'API)
//   3. La synchronisation : on attend que LES DEUX soient terminés avant d'afficher
//
import { useState, useCallback, useRef } from 'react';
import { scanDomain, extractApiError } from '../lib/api';
import type { ConsoleLog, ScanResult, ScanStatus } from '../types/scanner';

// ── Séquence de simulation des logs ──────────────────────────────────────────

interface SimStep {
  message:  string;
  delay:    number;   // ms depuis le début
  type:     ConsoleLog['type'];
}

const buildSimSteps = (domain: string): SimStep[] => [
  { delay: 0,    type: 'system',  message: `CyberHealth Scanner v1.0 — cible : ${domain}` },
  { delay: 180,  type: 'info',    message: `→ Résolution DNS de ${domain}...` },
  { delay: 420,  type: 'info',    message: '→ Interrogation des serveurs de noms autoritaires...' },
  { delay: 720,  type: 'info',    message: '→ Recherche de l\'enregistrement SPF (TXT)...' },
  { delay: 1050, type: 'info',    message: '→ Vérification de la politique DMARC (_dmarc)...' },
  { delay: 1380, type: 'info',    message: '→ Initiation du handshake TLS sur le port 443...' },
  { delay: 1650, type: 'info',    message: '→ Extraction du certificat X.509...' },
  { delay: 1900, type: 'info',    message: '→ Vérification de la chaîne de certification (CA)...' },
  { delay: 2150, type: 'info',    message: '→ Négociation de la version TLS...' },
  { delay: 2450, type: 'warning', message: '→ Scan TCP des ports critiques [21, 22, 23, 80, 443, 445, 3306, 3389, 5432]...' },
  { delay: 2750, type: 'warning', message: '→ Test d\'exposition RDP (Port 3389) — vecteur ransomware #1...' },
  { delay: 3050, type: 'warning', message: '→ Test d\'exposition SMB (Port 445) — vecteur WannaCry/NotPetya...' },
  { delay: 3300, type: 'warning', message: '→ Test d\'accès aux bases de données (3306/5432)...' },
  { delay: 3550, type: 'warning', message: '→ Détection des protocoles obsolètes (FTP/Telnet)...' },
  { delay: 3800, type: 'info',    message: '→ Agrégation des findings de sécurité...' },
  { delay: 4050, type: 'info',    message: '→ Application du moteur de scoring (base 100)...' },
  { delay: 4300, type: 'info',    message: '→ Calcul de l\'estimation de risque financier...' },
  { delay: 4550, type: 'info',    message: '→ Génération du rapport JSON...' },
];

const SIMULATION_TOTAL_MS = 4800; // durée totale de la simulation

// ── Types exportés ────────────────────────────────────────────────────────────

export interface ScannerState {
  status:        ScanStatus;
  result:        ScanResult | null;
  error:         string | null;
  consoleLogs:   ConsoleLog[];
  progress:      number;  // 0–100
}

export interface ScannerActions {
  startScan: (domain: string) => Promise<void>;
  reset:     () => void;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

let logCounter = 0;
function makeLog(message: string, type: ConsoleLog['type']): ConsoleLog {
  return {
    id:        `log-${++logCounter}`,
    message,
    type,
    timestamp: new Date().toLocaleTimeString('fr-FR', { hour12: false }),
  };
}

// ── Hook principal ────────────────────────────────────────────────────────────

export function useScanner(): ScannerState & ScannerActions {
  const [state, setState] = useState<ScannerState>({
    status:      'idle',
    result:      null,
    error:       null,
    consoleLogs: [],
    progress:    0,
  });

  // Refs pour les timers — nettoyage si reset()
  const timersRef  = useRef<ReturnType<typeof setTimeout>[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearAllTimers = () => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const appendLog = useCallback((log: ConsoleLog) => {
    setState(prev => ({
      ...prev,
      consoleLogs: [...prev.consoleLogs, log],
    }));
  }, []);

  const startScan = useCallback(async (domain: string) => {
    clearAllTimers();
    logCounter = 0;

    // Réinitialiser l'état
    setState({
      status:      'scanning',
      result:      null,
      error:       null,
      consoleLogs: [],
      progress:    0,
    });

    const steps = buildSimSteps(domain);

    // ── 1. Lancer la simulation des logs (indépendante de l'API) ─────────────
    steps.forEach((step) => {
      const t = setTimeout(() => {
        appendLog(makeLog(step.message, step.type));
      }, step.delay);
      timersRef.current.push(t);
    });

    // ── 2. Progress bar (se remplit sur SIMULATION_TOTAL_MS) ─────────────────
    const startTime = Date.now();
    intervalRef.current = setInterval(() => {
      const elapsed  = Date.now() - startTime;
      const progress = Math.min(95, Math.round((elapsed / SIMULATION_TOTAL_MS) * 95));
      setState(prev => ({ ...prev, progress }));
    }, 60);

    // ── 3. Appel API réel (parallèle) ─────────────────────────────────────────
    let apiResult: ScanResult | null = null;
    let apiError:  string | null     = null;

    try {
      apiResult = await scanDomain(domain);
    } catch (err) {
      apiError = extractApiError(err);
    }

    // ── 4. Attendre que la simulation soit terminée avant d'afficher ──────────
    const elapsed = Date.now() - startTime;
    const remaining = Math.max(0, SIMULATION_TOTAL_MS - elapsed);

    setTimeout(() => {
      clearAllTimers();

      if (apiError || !apiResult) {
        appendLog(makeLog(`✗ Erreur : ${apiError ?? 'Réponse invalide'}`, 'error'));
        setState(prev => ({
          ...prev,
          status:   'error',
          error:    apiError,
          progress: 0,
        }));
        return;
      }

      // Log de fin contextuel
      const score = apiResult.security_score;
      const finalType: ConsoleLog['type'] =
        score >= 70 ? 'success' : score >= 40 ? 'warning' : 'error';
      const finalMsg = score >= 70
        ? `✓ Scan terminé — SecurityScore : ${score}/100 — Niveau : ${apiResult.risk_level}`
        : `⚠ Scan terminé — SecurityScore CRITIQUE : ${score}/100 — ${apiResult.findings.length} vulnérabilité(s) détectée(s)`;

      appendLog(makeLog(finalMsg, finalType));

      setState(prev => ({
        ...prev,
        status:   'success',
        result:   apiResult,
        progress: 100,
      }));
    }, remaining + 200); // 200ms de marge pour le dernier log

  }, [appendLog]);

  const reset = useCallback(() => {
    clearAllTimers();
    setState({
      status:      'idle',
      result:      null,
      error:       null,
      consoleLogs: [],
      progress:    0,
    });
  }, []);

  return { ...state, startScan, reset };
}
