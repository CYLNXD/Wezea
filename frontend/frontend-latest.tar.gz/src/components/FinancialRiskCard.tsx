// ─── FinancialRiskCard — Estimation de l'impact financier d'une attaque ───────
//
// Formule affichée :
//   Perte_Estimée = (C_interruption × Jours) + C_restauration + Amende_RGPD
//
import { motion } from 'framer-motion';
import { TrendingDown, AlertCircle, Euro } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import type { FinancialRisk, RiskLevel } from '../types/scanner';

interface Props {
  financialRisk: FinancialRisk;
  riskLevel:     RiskLevel;
  score:         number;
}

// Hypothèses de calcul (affichées à l'utilisateur pour transparence)
const ASSUMPTIONS: Record<RiskLevel, {
  days:           number;
  daily_cost:     number;
  restoration:    number;
  gdpr_fine:      number;
  downtime_key:   string;
}> = {
  CRITICAL: { days: 8,  daily_cost: 4_500, restoration: 25_000, gdpr_fine: 30_000, downtime_key: 'downtime_critical' },
  HIGH:     { days: 4,  daily_cost: 3_500, restoration: 12_000, gdpr_fine: 12_000, downtime_key: 'downtime_high' },
  MEDIUM:   { days: 2,  daily_cost: 2_000, restoration: 5_000,  gdpr_fine: 4_000,  downtime_key: 'downtime_medium' },
  LOW:      { days: 0.5, daily_cost: 1_500, restoration: 1_500,  gdpr_fine: 500,    downtime_key: 'downtime_low'   },
};

function formatEur(n: number) {
  return n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
}

export function FinancialRiskCard({ financialRisk, riskLevel, score }: Props) {
  const { t } = useLanguage();
  const a    = ASSUMPTIONS[riskLevel];
  const calc = {
    interruption: Math.round(a.daily_cost * a.days),
    restoration:  a.restoration,
    gdpr:         a.gdpr_fine,
    total:        Math.round(a.daily_cost * a.days) + a.restoration + a.gdpr_fine,
  };

  const isCritical = score < 50;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className={`
        rounded-xl border overflow-hidden
        ${isCritical
          ? 'border-red-500/50 bg-red-500/5'
          : 'border-orange-500/40 bg-orange-500/5'}
      `}
    >
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className={`
        flex items-center gap-3 px-5 py-4 border-b
        ${isCritical ? 'border-red-500/30 bg-red-900/10' : 'border-orange-500/25 bg-orange-900/10'}
      `}>
        <TrendingDown
          size={20}
          className={isCritical ? 'text-red-400' : 'text-orange-400'}
        />
        <div>
          <h3 className={`font-bold text-sm ${isCritical ? 'text-red-300' : 'text-orange-300'}`}>
            {t('fin_title')}
          </h3>
          <p className="text-slate-500 text-xs font-mono">
            {t('fin_subtitle')}
          </p>
        </div>
        <span className={`
          ml-auto text-xs font-bold px-2.5 py-1 rounded font-mono
          ${isCritical
            ? 'bg-red-500/20 text-red-300 border border-red-500/30'
            : 'bg-orange-500/20 text-orange-300 border border-orange-500/30'}
        `}>
          {t('risk_label', { label: financialRisk.risk_label.toUpperCase() })}
        </span>
      </div>

      {/* ── Formule ─────────────────────────────────────────────────────── */}
      <div className="px-5 py-4">

        {/* Formule mathématique stylisée */}
        <div className="bg-slate-950/70 rounded-lg border border-slate-800 p-4 mb-5 font-mono text-center">
          <p className="text-slate-500 text-[10px] uppercase tracking-widest mb-2">
            {t('fin_model')}
          </p>
          <p className="text-slate-300 text-xs leading-loose">
            {t('fin_formula')}
          </p>
        </div>

        {/* Détail des postes */}
        <div className="flex flex-col gap-2 mb-5">
          <CostRow
            label={t('fin_downtime', { label: t(a.downtime_key as any) })}
            formula={t('fin_downtime_calc', { daily: formatEur(a.daily_cost), days: a.days })}
            value={calc.interruption}
            color="text-amber-400"
          />
          <CostRow
            label={t('fin_restore')}
            formula={t('fin_restore_sub')}
            value={calc.restoration}
            color="text-orange-400"
          />
          <CostRow
            label={t('fin_gdpr')}
            formula={t('fin_gdpr_sub')}
            value={calc.gdpr}
            color="text-red-400"
          />

          {/* Ligne totale */}
          <div className={`
            flex items-center justify-between pt-3 mt-1
            border-t ${isCritical ? 'border-red-500/30' : 'border-orange-500/25'}
          `}>
            <div className="flex items-center gap-2">
              <Euro size={16} className={isCritical ? 'text-red-400' : 'text-orange-400'} />
              <span className="font-bold text-slate-200 text-sm">
                {t('fin_total')}
              </span>
            </div>
            <div className="text-right">
              <p className={`font-black text-xl font-mono ${isCritical ? 'text-red-400' : 'text-orange-400'}`}
                style={{ textShadow: isCritical ? '0 0 20px rgba(239,68,68,0.4)' : '0 0 20px rgba(249,115,22,0.4)' }}>
                {formatEur(calc.total)}
              </p>
              <p className="text-slate-500 text-[10px] font-mono">
                {t('fin_range', { min: formatEur(financialRisk.loss_min_eur), max: formatEur(financialRisk.loss_max_eur) })}
              </p>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="flex gap-2 bg-slate-900/60 rounded-lg p-3 border border-slate-800">
          <AlertCircle size={13} className="text-slate-500 mt-0.5 shrink-0" />
          <p className="text-slate-500 text-[10px] leading-relaxed">
            {t('fin_disclaimer')}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

// ── Sous-composant ligne de coût ──────────────────────────────────────────────

function CostRow({
  label, formula, value, color,
}: {
  label: string; formula: string; value: number; color: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 py-2 border-b border-slate-800/60">
      <div className="flex-1 min-w-0">
        <p className="text-slate-300 text-xs">{label}</p>
        <p className="text-slate-600 text-[10px] font-mono mt-0.5">{formula}</p>
      </div>
      <span className={`font-mono font-bold text-sm shrink-0 ${color}`}>
        {formatEur(value)}
      </span>
    </div>
  );
}
