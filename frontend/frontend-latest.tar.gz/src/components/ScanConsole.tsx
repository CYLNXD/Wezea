// ─── ScanConsole — Terminal animé simulant les étapes du scan ─────────────────
import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Loader2 } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import type { ConsoleLog } from '../types/scanner';

interface Props {
  logs:     ConsoleLog[];
  progress: number;       // 0–100
  domain:   string;
}

// Couleurs par type de log
const LOG_COLORS: Record<ConsoleLog['type'], string> = {
  system:  'text-cyan-400 font-bold',
  info:    'text-slate-300',
  success: 'text-green-400',
  warning: 'text-amber-400',
  error:   'text-red-400',
};

const LOG_PREFIXES: Record<ConsoleLog['type'], string> = {
  system:  '[SYS] ',
  info:    '[INF] ',
  success: '[OK]  ',
  warning: '[WRN] ',
  error:   '[ERR] ',
};

export function ScanConsole({ logs, progress, domain }: Props) {
  const { t } = useLanguage();
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll vers le bas à chaque nouveau log
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -16 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="w-full max-w-3xl mx-auto"
    >
      {/* Fenêtre terminal */}
      <div className="rounded-xl border border-slate-700/70 bg-slate-950 shadow-2xl overflow-hidden">

        {/* Barre de titre façon terminal macOS */}
        <div className="flex items-center gap-2 px-4 py-3 bg-slate-900 border-b border-slate-700/60">
          <span className="w-3 h-3 rounded-full bg-red-500/80" />
          <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
          <span className="w-3 h-3 rounded-full bg-green-500/80" />
          <div className="flex items-center gap-2 ml-4 text-slate-400 text-xs font-mono">
            <Terminal size={13} />
            <span>{t('console_title', { domain })}</span>
          </div>
          {/* Spinner actif */}
          <Loader2
            size={13}
            className="ml-auto text-cyan-400 animate-spin"
          />
        </div>

        {/* Corps du terminal */}
        <div className="h-72 overflow-y-auto p-4 font-mono text-xs leading-relaxed">
          <AnimatePresence initial={false}>
            {logs.map((log) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.18 }}
                className="flex gap-2 mb-1"
              >
                <span className="text-slate-600 select-none shrink-0">
                  {log.timestamp}
                </span>
                <span className={LOG_COLORS[log.type]}>
                  <span className="text-slate-500">{LOG_PREFIXES[log.type]}</span>
                  {log.message}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Curseur clignotant */}
          <div className="flex items-center gap-1 mt-1">
            <span className="text-slate-600 text-xs">
              {new Date().toLocaleTimeString('fr-FR', { hour12: false })}
            </span>
            <span className="text-slate-500 text-xs ml-2">[INF] </span>
            <motion.span
              animate={{ opacity: [1, 0, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="inline-block w-2 h-3 bg-cyan-400 rounded-sm"
            />
          </div>
          <div ref={bottomRef} />
        </div>

        {/* Barre de progression */}
        <div className="px-4 py-3 bg-slate-900/60 border-t border-slate-700/60">
          <div className="flex items-center justify-between mb-2 text-xs text-slate-400 font-mono">
            <span>{t('console_scanning')}</span>
            <span className="text-cyan-400 font-semibold">{progress}%</span>
          </div>
          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{
                background: 'linear-gradient(90deg, #0ea5e9, #06b6d4, #22d3ee)',
                boxShadow: '0 0 12px rgba(14,165,233,0.6)',
              }}
              initial={{ width: '0%' }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
            />
          </div>
        </div>
      </div>

      {/* Texte statut en dessous */}
      <motion.p
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="text-center text-slate-500 text-sm font-mono mt-4"
      >
        {t('console_passive')}
      </motion.p>
    </motion.div>
  );
}
