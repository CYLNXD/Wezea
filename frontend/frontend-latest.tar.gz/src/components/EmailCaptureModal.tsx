// ─── EmailCaptureModal — Lead capture + téléchargement PDF automatique ────────
//
// Flux UX :
//   1. L'utilisateur remplit email + prénom + société
//   2. On appelle simultanément :
//      a. POST /report/request  → enregistrement CRM (lead)
//      b. POST /generate-pdf    → génération du PDF en mémoire
//   3. Dès que le PDF est prêt, le navigateur lance le téléchargement automatique
//   4. On affiche l'écran de succès avec confirmation
//
import { useState, FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, Mail, User, Building2, FileText,
  Loader2, CheckCircle2, Download, AlertCircle,
  FileDown, Shield,
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { requestFullReport, generatePDF, downloadBlob, extractApiError } from '../lib/api';
import type { ScanResult } from '../types/scanner';

// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  open:        boolean;
  onClose:     () => void;
  domain:      string;
  score:       number;
  scanResult:  ScanResult | null;   // ← données complètes pour le PDF
}

type ModalState = 'idle' | 'loading' | 'generating_pdf' | 'success' | 'error';

// ─────────────────────────────────────────────────────────────────────────────

export function EmailCaptureModal({ open, onClose, domain, score, scanResult }: Props) {
  const { t } = useLanguage();
  const [modalState, setModalState] = useState<ModalState>('idle');
  const [errorMsg,   setErrorMsg]   = useState('');
  const [pdfReady,   setPdfReady]   = useState(false);
  const [pdfBlob,    setPdfBlob]    = useState<Blob | null>(null);
  const [form, setForm] = useState({
    email:      '',
    first_name: '',
    last_name:  '',
    company:    '',
  });

  const isCritical = score < 40;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setModalState('loading');
    setErrorMsg('');
    setPdfReady(false);
    setPdfBlob(null);

    try {
      // ── Étape 1 : Enregistrement CRM (lead) + génération PDF en parallèle ──
      const leadPromise = requestFullReport({
        ...form,
        domain,
        scan_data: scanResult as Record<string, unknown> | null,
      });

      let pdfPromise: Promise<Blob> | null = null;
      if (scanResult) {
        setModalState('generating_pdf');
        pdfPromise = generatePDF(scanResult);
      }

      // Attendre les deux promesses (CRM peut échouer silencieusement)
      const [, blob] = await Promise.allSettled([
        leadPromise,
        pdfPromise ?? Promise.resolve(null),
      ]).then(results => [
        results[0].status === 'fulfilled' ? results[0].value : null,
        results[1].status === 'fulfilled' ? results[1].value : null,
      ]);

      // ── Étape 2 : Déclencher le téléchargement si PDF généré ─────────────
      if (blob) {
        const filename = `cyberhealth-rapport-${domain}-${new Date().toISOString().slice(0, 10)}.pdf`;
        downloadBlob(blob as Blob, filename);
        setPdfBlob(blob as Blob);
        setPdfReady(true);
      }

      setModalState('success');
    } catch (err) {
      setErrorMsg(extractApiError(err));
      setModalState('error');
    }
  };

  const handleRetryDownload = () => {
    if (pdfBlob) {
      const filename = `cyberhealth-rapport-${domain}.pdf`;
      downloadBlob(pdfBlob, filename);
    }
  };

  const reset = () => {
    setModalState('idle');
    setErrorMsg('');
    setPdfReady(false);
    onClose();
  };

  const isLoading = modalState === 'loading' || modalState === 'generating_pdf';

  // ── Texte du bouton selon l'état ───────────────────────────────────────────
  const buttonLabel = (() => {
    if (modalState === 'loading')        return t('modal_btn_loading');
    if (modalState === 'generating_pdf') return t('modal_btn_pdf');
    return scanResult ? t('modal_btn_download') : t('modal_btn_email');
  })();

  // ── Couleur accentuée selon score ──────────────────────────────────────────
  const accent = isCritical
    ? { from: 'from-red-700', to: 'to-orange-700', ring: 'ring-red-500/30', text: 'text-red-300', border: 'border-red-500/30' }
    : { from: 'from-cyan-600', to: 'to-blue-600',  ring: 'ring-cyan-500/30', text: 'text-cyan-300', border: 'border-cyan-500/30' };

  return createPortal(
    <AnimatePresence>
      {open && (
        <>
          {/* ── Overlay + centrage flex ────────────────────────────────── */}
          <motion.div
            key="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={!isLoading ? reset : undefined}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm z-40 flex items-center justify-center p-4"
          >
          {/* ── Modal — stoppons la propagation du click sur l'overlay ── */}
          <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.93 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: 'spring', damping: 22, stiffness: 280 }}
            onClick={e => e.stopPropagation()}
            className="
              relative w-full max-w-[500px]
              bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl
              z-50 overflow-hidden max-h-[90vh] overflow-y-auto
            "
          >
            {/* ── Gradient header ──────────────────────────────────── */}
            <div className={`
              relative px-6 pt-6 pb-5 border-b border-slate-700
              bg-gradient-to-br from-slate-800 to-slate-900
            `}>
              {!isLoading && (
                <button
                  onClick={reset}
                  className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors"
                  aria-label="Fermer"
                >
                  <X size={18} />
                </button>
              )}

              {/* Icône + titre */}
              <div className="flex items-center gap-3 mb-3">
                <div className={`
                  p-2.5 rounded-xl border
                  ${isCritical
                    ? 'bg-red-500/10 border-red-500/30'
                    : 'bg-cyan-500/10 border-cyan-500/30'}
                `}>
                  <FileDown size={20} className={accent.text} />
                </div>
                <div>
                  <h2 className="text-white font-bold text-lg leading-tight">
                    {t('modal_title')}
                  </h2>
                  <p className="text-slate-400 text-xs mt-0.5">
                    {scanResult
                      ? t('modal_pdf_sub')
                      : t('modal_email_sub')}
                  </p>
                </div>
              </div>

              {/* Pitch contextuel selon score */}
              {isCritical ? (
                <div className="flex gap-2.5 bg-red-500/10 border border-red-500/25 rounded-xl p-3">
                  <AlertCircle size={15} className="text-red-400 mt-0.5 shrink-0" />
                  <p className="text-red-200 text-xs leading-relaxed">
                    {t('modal_critical_body', { score })}
                  </p>
                </div>
              ) : (
                <p className="text-slate-400 text-sm leading-relaxed">
                  {t('modal_normal_body_1')}{' '}
                  <strong className="text-slate-200">{t('modal_normal_body_pages')}</strong>{' '}
                  {t('modal_normal_body_2')}{' '}
                  <span className={`font-semibold ${accent.text}`}>{t('modal_consult')}</span>.
                </p>
              )}

              {/* Score pill */}
              <div className={`
                mt-3 inline-flex items-center gap-2
                bg-slate-950/60 px-3 py-1.5 rounded-lg border ${accent.border}
                text-xs font-mono
              `}>
                <Shield size={11} className={accent.text} />
                <span className="text-slate-500">{t('modal_score')}:</span>
                <span className={`font-bold ${
                  score < 40 ? 'text-red-400' : score < 70 ? 'text-orange-400' : 'text-green-400'
                }`}>{score}/100</span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400 font-mono">{domain}</span>
              </div>
            </div>

            {/* ── Corps du modal ───────────────────────────────────── */}
            <div className="px-6 py-5">
              <AnimatePresence mode="wait">

                {/* ── Formulaire ──────────────────────────────────── */}
                {modalState !== 'success' && (
                  <motion.form
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, y: -8 }}
                    onSubmit={handleSubmit}
                    className="flex flex-col gap-3"
                  >
                    {/* Prénom + Nom */}
                    <div className="grid grid-cols-2 gap-3">
                      <InputField
                        icon={<User size={14} />}
                        id="first_name"
                        name="first_name"
                        autoComplete="given-name"
                        placeholder={t('modal_firstname')}
                        value={form.first_name}
                        onChange={handleChange}
                        disabled={isLoading}
                        required
                      />
                      <InputField
                        icon={<User size={14} />}
                        id="last_name"
                        name="last_name"
                        autoComplete="family-name"
                        placeholder={t('modal_lastname')}
                        value={form.last_name}
                        onChange={handleChange}
                        disabled={isLoading}
                        required
                      />
                    </div>

                    {/* Entreprise */}
                    <InputField
                      icon={<Building2 size={14} />}
                      id="company"
                      name="company"
                      autoComplete="organization"
                      placeholder={t('modal_company')}
                      value={form.company}
                      onChange={handleChange}
                      disabled={isLoading}
                    />

                    {/* Email */}
                    <InputField
                      icon={<Mail size={14} />}
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      placeholder={t('modal_email')}
                      value={form.email}
                      onChange={handleChange}
                      disabled={isLoading}
                      required
                    />

                    {/* Message d'erreur */}
                    {modalState === 'error' && (
                      <motion.div
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2.5"
                      >
                        <AlertCircle size={13} className="shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </motion.div>
                    )}

                    {/* Indicateur de progression PDF */}
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex items-center gap-2.5 bg-slate-800/60 border border-slate-700 rounded-lg px-3 py-2.5 text-xs"
                      >
                        <Loader2 size={13} className={`animate-spin ${accent.text}`} />
                        <div className="flex-1">
                          <p className="text-slate-300 font-medium">
                            {modalState === 'generating_pdf'
                              ? t('modal_gen_title')
                              : t('modal_gen_sub')}
                          </p>
                          <p className="text-slate-500 mt-0.5">
                            {modalState === 'generating_pdf'
                              ? t('modal_connect')
                              : t('modal_legal')}
                          </p>
                        </div>
                      </motion.div>
                    )}

                    {/* Bouton principal */}
                    <button
                      type="submit"
                      disabled={isLoading}
                      className={`
                        mt-1 flex items-center justify-center gap-2
                        w-full py-3 rounded-xl font-bold text-sm text-white
                        bg-gradient-to-r ${accent.from} ${accent.to}
                        hover:brightness-110
                        disabled:opacity-55 disabled:cursor-not-allowed
                        transition-all duration-200 shadow-lg ring-1 ${accent.ring}
                        focus:outline-none focus:ring-2
                      `}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 size={16} className="animate-spin" />
                          {buttonLabel}
                        </>
                      ) : (
                        <>
                          {scanResult ? <Download size={16} /> : <Mail size={16} />}
                          {buttonLabel}
                        </>
                      )}
                    </button>

                    {/* Mention légale */}
                    <p className="text-center text-[10px] text-slate-600 leading-relaxed">
                      {t('modal_consult')}
                    </p>
                  </motion.form>
                )}

                {/* ── Succès + téléchargement ──────────────────────── */}
                {modalState === 'success' && (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.94 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                    className="flex flex-col items-center gap-4 py-4 text-center"
                  >
                    {/* Icône animée */}
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', damping: 12, stiffness: 200 }}
                      className="p-4 rounded-full bg-green-500/10 border border-green-500/30"
                    >
                      <CheckCircle2 size={38} className="text-green-400" />
                    </motion.div>

                    <div>
                      <h3 className="text-white font-bold text-xl mb-1">
                        {pdfReady ? t('modal_success_pdf') : t('modal_success_req')}
                      </h3>
                      <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
                        {pdfReady
                          ? t('modal_success_pdf_body')
                          : t('modal_success_email_body', { email: form.email })}
                      </p>
                    </div>

                    {/* Actions post-succès */}
                    <div className="flex flex-col gap-2 w-full">
                      {/* Re-télécharger si PDF disponible */}
                      {pdfBlob && (
                        <button
                          onClick={handleRetryDownload}
                          className={`
                            flex items-center justify-center gap-2 w-full py-2.5 rounded-xl
                            bg-gradient-to-r ${accent.from} ${accent.to}
                            text-white font-semibold text-sm
                            hover:brightness-110 transition-all
                          `}
                        >
                          <FileText size={15} />
                          {t('modal_redownload')}
                        </button>
                      )}

                      {/* Prochaines étapes */}
                      <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 text-left w-full">
                        <p className="text-slate-300 text-xs font-semibold mb-2 flex items-center gap-1.5">
                          <Shield size={12} className="text-cyan-400" />
                          {t('modal_next_steps')}
                        </p>
                        <ul className="text-slate-500 text-xs space-y-1.5">
                          <li className="flex gap-2">
                            <span className="text-cyan-400 shrink-0">→</span>
                            {t('modal_step1')}
                          </li>
                          <li className="flex gap-2">
                            <span className="text-cyan-400 shrink-0">→</span>
                            {t('modal_step2')}
                          </li>
                          <li className="flex gap-2">
                            <span className="text-cyan-400 shrink-0">→</span>
                            {t('modal_step3')}
                          </li>
                        </ul>
                      </div>

                      <button
                        onClick={reset}
                        className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-sm font-medium transition-colors"
                      >
                        {t('btn_close')}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body
  );
}

// ── Sub-composant champ de formulaire ─────────────────────────────────────────

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon: React.ReactNode;
}

function InputField({ icon, ...props }: InputProps) {
  return (
    <div className="relative flex items-center">
      <span className="absolute left-3 text-slate-500 pointer-events-none">
        {icon}
      </span>
      <input
        {...props}
        className="
          w-full pl-9 pr-3 py-2.5
          bg-slate-800 border border-slate-700 rounded-lg
          text-slate-200 text-sm placeholder:text-slate-500
          focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/60
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-all duration-150
        "
      />
    </div>
  );
}
