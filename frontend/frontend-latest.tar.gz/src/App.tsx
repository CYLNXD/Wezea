// ─── App.tsx — Racine React ────────────────────────────────────────────────────
import Dashboard from './pages/Dashboard';
import { LanguageProvider } from './i18n/LanguageContext';

export default function App() {
  return (
    <LanguageProvider>
      <Dashboard />
    </LanguageProvider>
  );
}
